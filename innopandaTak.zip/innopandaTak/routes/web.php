<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;



Route::get('/', [ProductController::class, 'index'])->name('home');

Route::get('/add-to-cart/{id}', [ProductController::class, 'addToCart'])->name('add.to.cart');

Route::get('/cart', [ProductController::class, 'viewCart'])->name('view.cart');
// Route for updating quantity
Route::put('/cart/update-quantity/{id}', [ProductController::class, 'updateQuantity'])->name('cart.updateQuantity');

// Route for deleting from cart
Route::delete('/cart/delete/{id}', [ProductController::class, 'deleteFromCart'])->name('cart.deleteFromCart');




Route::get('/dashboard', [ProductController::class, 'index'])->middleware(['auth', 'verified'])->name('dashboard');

// Route for viewing the cart

    // Route::get('/dashboard', function () {
    //     return view('dashboard');
    // })->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});













require __DIR__.'/auth.php';
