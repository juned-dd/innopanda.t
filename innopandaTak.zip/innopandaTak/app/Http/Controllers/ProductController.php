<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Session;

use App\Models\Cart;

class ProductController extends Controller
{

    public function index()
    {
        $products = Product::all();
        $cartCount = Cart::count(); // Counting all items in the cart
        return view('products.index', compact('products', 'cartCount'));
    }


    // public function addToCart($productId)
    // {
    //     // Get the product from the database
    //     $product = Product::find($productId);

    //     if (!$product) {
    //         return redirect()->back()->with('error', 'Product not found');
    //     }

    //     // Assuming you're still tracking cart items based on product ID
    //     $cart = Cart::where('product_id', $productId)->first();

    //     // Check if the product is already in the cart
    //     if ($cart) {
    //         // If the product is already in the cart, increase the quantity
    //         $cart->quantity += 1;
    //         $cart->save();
    //     } else {
    //         // If the product is not in the cart, add a new entry
    //         Cart::create([
    //             'product_id' => $productId,
    //             'quantity' => 1,
    //         ]);
    //     }
    //     return back()->with('success', 'Product added to cart');
    // }


    public function addToCart($productId)
    {

        if (!Auth::check()) {

            return redirect('/')->with('error', 'Please log in first to add products to your cart');
        }


        $product = Product::find($productId);

        if (!$product) {
            return redirect()->back()->with('error', 'Product not found');
        }


        $cart = Cart::where('product_id', $productId)->where('user_id', Auth::id())->first();


        if ($cart) {

            $cart->quantity += 1;
            $cart->save();
        } else {

            Cart::create([
                'user_id' => Auth::id(),
                'product_id' => $productId,
                'quantity' => 1,
            ]);
        }

        return back()->with('success', 'Product added to cart');
    }




    public function updateQuantity(Request $request, $cartId)
    {
        $cartItem = Cart::find($cartId);

        if (!$cartItem) {
            return redirect()->back()->with('error', 'Item not found');
        }


        $validated = $request->validate([
            'quantity' => 'required|integer|min:1'
        ]);


        $cartItem->quantity = $validated['quantity'];
        $cartItem->save();

        return redirect()->route('view.cart')->with('success', 'Quantity updated');
    }

    public function deleteFromCart($cartId)
    {
        $cartItem = Cart::find($cartId);

        if (!$cartItem) {
            return redirect()->back()->with('error', 'Item not found');
        }


        $cartItem->delete();

        return redirect()->route('view.cart')->with('success', 'Item removed from cart');
    }


public function viewCart()
{

    $cartItems = Cart::with('product')->get();

    // Pass the cart items to the view
    return view('cart.index', ['cart' => $cartItems]);
}


}
