<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container mt-5">
        <h1>Your Cart</h1>

        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mb-3">Back</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e($item->product->image); ?>" width="100" alt="<?php echo e($item->product->name); ?>"></td>
                    <td><?php echo e($item->product->name); ?></td>
                    <td>$<?php echo e($item->product->price); ?></td>
                    <td>
                        <!-- Form to update quantity -->
                        <form action="<?php echo e(route('cart.updateQuantity', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" min="1" style="width: 60px;">
                            <button type="submit" class="btn btn-primary btn-sm">Update</button>
                        </form>
                    </td>
                    <td>$<?php echo e($item->product->price * $item->quantity); ?></td>
                    <td>
                        <!-- Form to delete the item -->
                        <form action="<?php echo e(route('cart.deleteFromCart', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\InnopandaTask\project-name\resources\views/cart/index.blade.php ENDPATH**/ ?>