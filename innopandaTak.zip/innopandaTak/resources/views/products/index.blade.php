<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List with Add to Cart</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Your existing styles */
        body {
            font-family: Arial, sans-serif;
        }
        .navbar {
            background-color: #FF2D20;
            padding: 10px 20px;
        }
        .navbar a {
            color: white;
            font-weight: bold;
            margin-left: 15px;
            text-decoration: none;
        }
        .navbar a:hover {
            color: #FFFCF5;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .card img {
            border-radius: 10px 10px 0 0;
        }
        .card-body {
            padding: 20px;
            text-align: center;
        }
        .card-title {
            font-size: 18px;
            font-weight: bold;
        }
        .card-text {
            color: #777;
        }
        .btn {
            margin-top: 10px;
        }
        .cart-btn {
            background-color: #17a2b8;
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            text-transform: uppercase;
            font-weight: bold;
        }
        .cart-btn:hover {
            background-color: #138496;
        }
        .nav-buttons a {
            padding: 10px 20px;
            border-radius: 20px;
            font-size: 14px;
            text-transform: uppercase;
            transition: background-color 0.3s;
        }
        .nav-buttons a.login {
            background-color: #28a745;
            color: white;
        }
        .nav-buttons a.register {
            background-color: #007bff;
            color: white;
        }
        .nav-buttons a:hover {
            background-color: #FF2D20;
        }
    </style>
</head>
<body>

    <!-- Toast Notification -->
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 5">
        <div id="successToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <strong class="me-auto">Success</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                {{ session('success') }}
            </div>
        </div>
    </div>

    <!-- Navigation Bar -->
    <nav class="navbar">
        @if (Route::has('login'))
            <div class="nav-buttons d-flex justify-content-between">
                @auth
                    <!-- Dropdown Menu -->
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            {{ Auth::user()->name }}
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                            <li><a class="dropdown-item" href="{{ route('profile.edit') }}">Profile</a></li>
                            <li>
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <button type="submit" class="dropdown-item">Log Out</button>
                                </form>
                            </li>
                        </ul>
                    </div>

                    <!-- Add to Cart Button (Right-aligned) -->
                    <a href="{{ route('view.cart') }}" class="cart-btn ms-auto">
                        View Cart ({{ $cartCount }})
                    </a>
                @else
                    <a href="{{ route('login') }}" class="login">Log in</a>
                    @if (Route::has('register'))
                        <a href="{{ route('register') }}" class="register">Register</a>
                    @endif
                @endauth
            </div>
        @endif
    </nav>


    <div class="container mt-5">
        <h1 class="mb-4 text-center">Product List</h1>
        @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

        <!-- Displaying Products -->
        <div class="row">
            @foreach($products as $product)
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="{{ $product->image }}" class="card-img-top" alt="{{ $product->name }}">
                        <div class="card-body">
                            <h5 class="card-title">{{ $product->name }}</h5>
                            <p class="card-text">{{ $product->description }}</p>
                            <p class="card-text"><strong>Price: </strong>${{ $product->price }}</p>
                            <a href="{{ route('add.to.cart', $product->id) }}" class="btn btn-success">Add to Cart</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

    </div>

    <!-- Bootstrap JS (optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



<script>
    // Show success message if it exists
    @if(session('success'))
        var toastSuccess = new bootstrap.Toast(document.getElementById('successToast'));
        toastSuccess.show();
    @endif

    // Show error message if it exists
    @if(session('error'))
        var toastError = new bootstrap.Toast(document.getElementById('errorToast'));
        toastError.show();
    @endif
</script>

</body>
</html>
